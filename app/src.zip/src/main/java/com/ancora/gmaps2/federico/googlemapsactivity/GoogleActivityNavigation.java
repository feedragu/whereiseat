package com.ancora.gmaps2.federico.googlemapsactivity;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import com.ancora.gmaps2.federico.googlemapsactivity.models.LinkedSerializable;
import com.ancora.gmaps2.federico.googlemapsactivity.models.PlacesModel;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.SupportStreetViewPanoramaFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.StreetViewPanoramaLocation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class GoogleActivityNavigation extends AppCompatActivity
        implements  NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback, StreetViewPanorama.OnStreetViewPanoramaChangeListener, Serializable, OnStreetViewPanoramaReadyCallback {
    private GoogleMap mMap;
    private StreetViewPanorama street;
    private LocationListener mLocationListener;
    private LocationManager locationManager;
    private SupportStreetViewPanoramaFragment streetViewPanoramaFragment;
    private SupportMapFragment mapFragment;
    private View mContainerViewS;
    private View mContainerViewM;
    private ViewGroup googleLayout;
    private ArrayList<ViewGroup.LayoutParams> a;

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_activity_navigation);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        streetViewPanoramaFragment = (SupportStreetViewPanoramaFragment) getSupportFragmentManager()
                .findFragmentById(R.id.streetviewpanorama);
        streetViewPanoramaFragment.getStreetViewPanoramaAsync(this);
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        googleLayout = (ViewGroup) findViewById(R.id.google_layout);


        Button bt = (Button) findViewById(R.id.btnAllarga);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = moveFragments();
            }
        });
        Button btr = (Button) findViewById(R.id.btnRitorna);
        btr.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                TransitionManager.beginDelayedTransition(googleLayout);
                mContainerViewM.setLayoutParams(a.get(1));
                mContainerViewS.setLayoutParams(a.get(0));
                mContainerViewS.setPadding(0, 0, 0, 0);
                mContainerViewS.setVisibility(View.VISIBLE);
            }
        });

        Button btp = (Button) findViewById(R.id.btnPos);
        btp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getIntent();
                LatLng l = i.getParcelableExtra("LatLong");
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(l, mMap.getCameraPosition().zoom));
            }
        });


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        mLocationListener = new LocationListener() {
            @Override
            public void onLocationChanged(final Location location) {
                Log.i("latitude", String.valueOf(location.getLatitude()));
                Log.i("longitude", String.valueOf(location.getLongitude()));
                LatLng l = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(l, mMap.getCameraPosition().zoom));
                street.setPosition(l);
               /* MarkerOptions a = new MarkerOptions()
                        .position(l);
                Marker m = mMap.addMarker(a);
                m.setPosition(l);*/
                /*long duration = 500;
                float tilt = 0;
                streetViewPanoramaFragment.getStreetViewPanorama().setPosition(l);
                mapFragment.getMap().addMarker(new MarkerOptions().position(l));
                CameraUpdateFactory.newLatLngZoom(l, 15);*/


            }

            @Override
            public void onStatusChanged(final String provider,
                                        final int status, final Bundle extras) {
            }

            @Override
            public void onProviderEnabled(final String provider) {
            }

            @Override
            public void onProviderDisabled(final String provider) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }


        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET
            }, 10);
            return;
        } else {
            configureButton();
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    configureButton();
                return;
        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    private void configureButton() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates("gps", 4000, 5, mLocationListener);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.google_activity_navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    public ArrayList<ViewGroup.LayoutParams> moveFragments() {
        mContainerViewS=findViewById(R.id.streetviewpanorama);
        mContainerViewM=findViewById(R.id.map);
        ViewGroup.LayoutParams oldOnesS=mContainerViewS.getLayoutParams();
        ViewGroup.LayoutParams oldOnesM=mContainerViewM.getLayoutParams();
        ArrayList<ViewGroup.LayoutParams> a=new ArrayList();
        a.add(oldOnesS);
        a.add(oldOnesM);
        TransitionManager.beginDelayedTransition(googleLayout);
        Log.i("prova", "funziona");
        FrameLayout.LayoutParams map=new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        mContainerViewS.setVisibility(View.INVISIBLE);
        mContainerViewS.setPadding(0, 1100, 800, 0);
        mContainerViewM.setLayoutParams(map);
        return a;

    }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {
            Intent i=getIntent();
            Bundle bundle = new Bundle();
            LinkedSerializable addressS= (LinkedSerializable) i.getExtras().getSerializable("address");
            bundle.putSerializable("address", addressS);
            Intent j=new Intent(this, ListActivity.class);
            j.putExtras(bundle);
            startActivity(j);
        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Intent i=getIntent();
        LatLng l=i.getParcelableExtra("LatLong");
        LinkedSerializable addressS= (LinkedSerializable) i.getExtras().getSerializable("address");
        LinkedList<PlacesModel> address= null;
        if (addressS != null) {
            address = addressS.getL();
        }
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.addMarker(new MarkerOptions().position(l).title("sono qui"));
        for(int j=0; j<address.size(); j++) {
            LatLng pos=new LatLng(Double.parseDouble(address.get(j).getLat()),Double.parseDouble(address.get(j).getLng()));
            MarkerOptions marker = new MarkerOptions().position(pos).title(address.get(j).getName());
            marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.cose2));
            mMap.addMarker(marker);
        }
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(l, 15));
    }

    @Override
    public void onStreetViewPanoramaReady(StreetViewPanorama streetViewPanorama) {
        Intent i = getIntent();
        street=streetViewPanorama;
        LatLng l = i.getParcelableExtra("LatLong");
        streetViewPanorama.setPosition(l);
        streetViewPanorama.setZoomGesturesEnabled(true);
        streetViewPanorama.setStreetNamesEnabled(true);
    }


    @Override
    public void onStreetViewPanoramaChange(StreetViewPanoramaLocation streetViewPanoramaLocation) {

    }
}
