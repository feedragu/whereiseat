package com.ancora.gmaps2.federico.googlemapsactivity;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.ancora.gmaps2.federico.googlemapsactivity.models.LinkedSerializable;
import com.ancora.gmaps2.federico.googlemapsactivity.models.PlacesModel;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;

import javax.net.ssl.HttpsURLConnection;


public class MainActivityFake extends FragmentActivity {
    private final int REQUEST_PLACE_PICKER=1;
    private Place pl;
    public LinkedList<PlacesModel> address;
    private String placeDetailsStr;
    private JSONTask json =new JSONTask();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView ed=(TextView) findViewById(R.id.txtPlaceDetails);
        Fragment f=getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment) f;
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                pl = place;
                placeDetailsStr = place.getLatLng().toString().substring(10, place.getLatLng().toString().length()-1);
                ed.setText(placeDetailsStr);
                ed.append(pl.getLatLng().toString());

            }

            @Override
            public void onError(Status status) {

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_PLACE_PICKER) {
            if (resultCode == RESULT_OK) {

            }
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void startMap(View v) throws IOException, InterruptedException {
            new Thread(new Runnable() {
                public void run() {
                    json.execute("https://maps.googleapis.com/maps/api/place/textsearch/json?location=" + placeDetailsStr + "&radius=1000&sensor=true&query=restaurant&key=AIzaSyC9-cMV9fsN4ZoW0dFuhDlJ1Q-eymOsuvg");
                }
            }).start();

        }

    public class JSONTask extends AsyncTask<String, String, LinkedList<PlacesModel>> {

        @Override
        protected LinkedList<PlacesModel> doInBackground(String... params) {
            URL url = null;
            try {
                url = new URL(params[0]);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpsURLConnection connection = null;
            BufferedReader br = null;

            try
            {
                connection=(HttpsURLConnection) url.openConnection();
                connection.connect();
                InputStream stream = null;
                stream = connection.getInputStream();
                br = new BufferedReader(new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    buffer.append(line);
                }
                String finalJSOn=buffer.toString();
                JSONObject parentObject= new JSONObject(finalJSOn);
                JSONArray parentArray=parentObject.getJSONArray("results");
                LinkedList<PlacesModel> array= new LinkedList<>();
                for(int i=0; i<parentArray.length(); i++) {
                    PlacesModel placesModel=new PlacesModel();
                    JSONObject finalObject=parentArray.getJSONObject(i);
                    placesModel.setName(finalObject.getString("name"));
                    JSONObject second=finalObject.getJSONObject("geometry");
                    JSONObject third=second.getJSONObject("location");
                    placesModel.setLat(third.getString("lat"));
                    placesModel.setLng(third.getString("lng"));
                    array.add(placesModel);
                }
                return array;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally
            {

                if (connection != null ) {
                    connection.disconnect();
                }
                try {
                    if (br != null) {
                        br.close();
                    }
                }catch(IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(LinkedList<PlacesModel> result) {
            super.onPostExecute(result);
            address=result;
            Intent i = new Intent(MainActivityFake.this, GoogleMapsActivity.class);
            Bundle bundle = new Bundle();
            bundle.putParcelable("LatLong", pl.getLatLng());
            LinkedSerializable link=new LinkedSerializable(address);
            bundle.putSerializable("address", link);
            i.putExtras(bundle);
            startActivityForResult(i, REQUEST_PLACE_PICKER);
        }
    }
}
