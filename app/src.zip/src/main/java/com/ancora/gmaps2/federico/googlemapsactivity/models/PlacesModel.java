package com.ancora.gmaps2.federico.googlemapsactivity.models;

import java.io.Serializable;

public class PlacesModel implements Serializable{
    private String lat;
    private String lng;
    private String id;
    private String name;
    private String photoRef;
    private String address;
    boolean open;
    private String placeId;
    private String rating;
    private String vicinity;
    private String width;

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhotoRef() {
        return photoRef;
    }

    public void setPhotoRef(String photoRef) {
        this.photoRef = photoRef;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getVicinity() {
        return vicinity;
    }

    public void setVicinity(String vicinity) {
        this.vicinity = vicinity;
    }

    public PlacesModel() {

    }

}

/* "results" : [
      {
         "geometry" : {
            "location" : {
               "lat" : -41.3153969,
               "lng" : 174.8167165
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",
         "id" : "809b242e5211a8e9ab295569f3c5bde6a80d2b5b",
         "name" : "La Boca Loca",
         "opening_hours" : {
            "open_now" : false,
            "weekday_text" : []
         },
         "photos" : [
            {
               "height" : 966,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/100190519034881204660/photos\"\u003eLa Boca Loca\u003c/a\u003e"
               ],
               "photo_reference" : "CmRdAAAAfvoKK34_ojvQWmB-14ZxAOczpCORTs5hkqZayP70AubvjD8lul1JTJOCaYYiNnBCdWKQjXZh85QB1pQ6iY7XgL-8mDBUz5PaYKoSfc-hSpRJbNw8Lr-E29UxucXoAeRdEhBuPHg463D9wPEmldewM4c3GhScETwTPUmKyfrfdiZev3ULn6yhSg",
               "width" : 965
            }
         ],
         "place_id" : "ChIJZwxJI3ivOG0RZnUiMf1i0_w",
         "rating" : 4.2,
         "reference" : "CmRgAAAAZe_G2y7G1ZvVoqZ3V9pVmWoIftaHipFMo9k8AS15_zbtI5D9O7lCL4fAa9glWQUlzpYc50Fmly_Kgs_a401QZgdzIO6Lpr26S29AysNfV_vKDewJR_hC8TTLTTxrIg1NEhD6K6yN027Ge-YiAFAFir5HGhR80nNLBUm-Gz6bbW1_xh9xFCeN_A",
         "scope" : "GOOGLE",
         "types" : [
            "cafe",
            "bar",
            "restaurant",
            "food",
            "point_of_interest",
            "establishment"
         ],
         "vicinity" : "19 Park Road, Miramar"
      }
      */
