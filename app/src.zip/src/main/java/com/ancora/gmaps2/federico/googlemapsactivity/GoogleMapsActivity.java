package com.ancora.gmaps2.federico.googlemapsactivity;


import android.annotation.TargetApi;
import android.content.Intent;
import android.location.Address;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import com.ancora.gmaps2.federico.googlemapsactivity.models.LinkedSerializable;
import com.ancora.gmaps2.federico.googlemapsactivity.models.PlacesModel;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.SupportStreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class GoogleMapsActivity extends AppCompatActivity implements OnMapReadyCallback, Serializable, OnStreetViewPanoramaReadyCallback{


        private GoogleMap mMap;
        private List<Address> pos;
        private LocationListener mLocationListener;
        private SupportStreetViewPanoramaFragment streetViewPanoramaFragment;
        private SupportMapFragment mapFragment;
        private int k=2;
        private View mContainerViewS;
        private View mContainerViewM;
        private ViewGroup googleLayout;
        private ArrayList<ViewGroup.LayoutParams> a;

    @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_google_maps);

            streetViewPanoramaFragment= (SupportStreetViewPanoramaFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.streetviewpanorama);
            streetViewPanoramaFragment.getStreetViewPanoramaAsync(this);
            mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);

            googleLayout=(ViewGroup) findViewById(R.id.google_layout);

            Button bt=(Button)findViewById(R.id.btnAllarga);
            final Button btr=(Button)findViewById(R.id.btnRitorna);
            btr.setEnabled(false);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a = moveFragments();
                    btr.setEnabled(true);
                }
            });


            btr.setOnClickListener(new View.OnClickListener() {
                @TargetApi(Build.VERSION_CODES.KITKAT)
                @Override
                public void onClick(View v) {
                    TransitionManager.beginDelayedTransition(googleLayout);
                    mContainerViewM.setLayoutParams(a.get(1));
                    mContainerViewS.setLayoutParams(a.get(0));
                    mContainerViewS.setPadding(0, 0, 0, 0);
                    mContainerViewS.setVisibility(View.VISIBLE);
                }
            });
            mLocationListener = new LocationListener() {

                @Override
                public void onLocationChanged(final Location location) {
                    LatLng l=new LatLng(location.getLatitude(), location.getLongitude());
                    long duration = 500;
                    float tilt = 0;
                    StreetViewPanoramaCamera camera = new StreetViewPanoramaCamera.Builder()
                            .zoom(streetViewPanoramaFragment.getStreetViewPanorama().getPanoramaCamera().zoom)
                            .bearing(streetViewPanoramaFragment.getStreetViewPanorama().getPanoramaCamera().bearing)
                            .tilt(tilt)
                            .build();
                    streetViewPanoramaFragment.getStreetViewPanorama().animateTo(camera, duration);
                    streetViewPanoramaFragment.getStreetViewPanorama().setPosition(l);
                    mapFragment.getMap().addMarker(new MarkerOptions().position(l));
                    CameraUpdateFactory.newLatLngZoom(l, 15);


                }

                @Override
                public void onStatusChanged(final String provider,
                                            final int status, final Bundle extras) {
                }

                @Override
                public void onProviderEnabled(final String provider) {
                }

                @Override
                public void onProviderDisabled(final String provider) {
                }
            };


        }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    public ArrayList<ViewGroup.LayoutParams> moveFragments() {
        mContainerViewS=findViewById(R.id.streetviewpanorama);
        mContainerViewM=findViewById(R.id.map);
        ViewGroup.LayoutParams oldOnesS=mContainerViewS.getLayoutParams();
        ViewGroup.LayoutParams oldOnesM=mContainerViewM.getLayoutParams();
        ArrayList<ViewGroup.LayoutParams> a=new ArrayList();
        a.add(oldOnesS);
        a.add(oldOnesM);
        TransitionManager.beginDelayedTransition(googleLayout);
        Log.i("prova", "funziona");
        FrameLayout.LayoutParams map=new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        mContainerViewS.setVisibility(View.INVISIBLE);
        mContainerViewS.setPadding(0, 1100, 800, 0);
        mContainerViewM.setLayoutParams(map);
        return a;

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Intent i=getIntent();
        LatLng l=i.getParcelableExtra("LatLong");
        LinkedSerializable addressS= (LinkedSerializable) i.getExtras().getSerializable("address");
        LinkedList<PlacesModel> address= null;
        if (addressS != null) {
            address = addressS.getL();
        }
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.addMarker(new MarkerOptions().position(l).title("sono qui"));
        for(int j=0; j<address.size(); j++) {
            LatLng pos=new LatLng(Double.parseDouble(address.get(j).getLat()),Double.parseDouble(address.get(j).getLng()));
            mMap.addMarker(new MarkerOptions().position(pos).title(address.get(j).getName()));
        }
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(l, 15));
    }


    @Override
    public void onStreetViewPanoramaReady(StreetViewPanorama streetViewPanorama) {
        Intent i = getIntent();
        LatLng l = i.getParcelableExtra("LatLong");
        streetViewPanorama.setPosition(l);
        streetViewPanorama.setZoomGesturesEnabled(true);
        streetViewPanorama.setStreetNamesEnabled(true);
    }

}
