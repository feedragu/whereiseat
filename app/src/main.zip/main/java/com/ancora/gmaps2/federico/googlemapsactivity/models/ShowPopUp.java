package com.ancora.gmaps2.federico.googlemapsactivity.models;

import android.app.*;
import android.media.Image;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.*;

import com.ancora.gmaps2.federico.googlemapsactivity.R;

public class ShowPopUp extends Activity {

    PopupWindow popUp;
    LinearLayout layout;
    TextView tv;
    LayoutParams params;
    LinearLayout mainLayout;
    Button but;



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        popUp = new PopupWindow(this);
        setContentView(R.layout.popup);
        ImageView iv=(ImageView) findViewById(R.id.image);
        DisplayMetrics dm=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width= dm.widthPixels;
        int height=dm.heightPixels;
        getWindow().setLayout((int)(width*.6), (int)(height*.6));
        /*tv = new TextView(this);
        popUp.showAtLocation(mainLayout, Gravity.BOTTOM, 600, 600);
        popUp.update(50, 50, 300, 80);
*/
    }
}