package com.ancora.gmaps2.federico.googlemapsactivity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.ancora.gmaps2.federico.googlemapsactivity.models.LinkedSerializable;
import com.ancora.gmaps2.federico.googlemapsactivity.models.PlacesModel;
import com.ancora.gmaps2.federico.googlemapsactivity.models.ShowPopUp;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MainActivityNavigation extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private final int REQUEST_PLACE_PICKER = 1;
    private Place pl;
    public LinkedList<PlacesModel> address = new LinkedList<>();
    private String placeDetailsStr;
    private double latitude = 45.453033;
    private double longitude = 9.164714;
    private LatLng coord;
    /*private JSONTask json = new JSONTask();
    private NextPage nextPage = new NextPage();
    private LocationListener mLocationListener;
    private LocationManager locationManager;*/
    private ListView lv;
    private Bitmap bitmap;
    private String next_page_token;


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        latitude=location.getLatitude();
        longitude=location.getLongitude();
        mLocationListener = new LocationListener() {
            @Override
            public void onLocationChanged(final Location location) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                Log.i("latitude", ""+latitude);
                Log.i("longitude", ""+longitude);
                /*LatLng l = new LatLng(location.getLatitude(), location.getLongitude());
               MarkerOptions a = new MarkerOptions()
                        .position(l);
                Marker m = mMap.addMarker(a);
                m.setPosition(l);*/
                /*long duration = 500;
                float tilt = 0;
                streetViewPanoramaFragment.getStreetViewPanorama().setPosition(l);
                mapFragment.getMap().addMarker(new MarkerOptions().position(l));
                CameraUpdateFactory.newLatLngZoom(l, 15);*/


           /* }

            @Override
            public void onStatusChanged(final String provider,
                                        final int status, final Bundle extras) {
            }

            @Override
            public void onProviderEnabled(final String provider) {
            }

            @Override
            public void onProviderDisabled(final String provider) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }


        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET
            }, 10);
            return;
        } else {
            configureButton();
        }
        SystemClock.sleep(1000);
        try {
            loadList();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        Intent i=getIntent();
        LinkedSerializable addressS= (LinkedSerializable) i.getExtras().getSerializable("address");
        LinkedList<PlacesModel> address= null;
        if (addressS != null) {
            address = addressS.getL();
        }
        PhotoAdapter ph=new PhotoAdapter(getApplicationContext(), R.layout.list, address);
        lv.setAdapter(ph);
        super.onCreate(savedInstanceState);
        SystemClock.sleep(2000);
        setContentView(R.layout.activity_main_activity_navigation);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final TextView ed = (TextView) findViewById(R.id.txtPlaceDetails);

        /*Fragment f=getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment) f;

        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                pl = place;
                placeDetailsStr = place.getLatLng().toString().substring(10, place.getLatLng().toString().length() - 1);
                ed.setText(placeDetailsStr);
                ed.append(pl.getLatLng().toString());

            }

            @Override
            public void onError(Status status) {

            }
        });*/

        lv = (ListView) findViewById(R.id.listView);

        Button pop = (Button) findViewById(R.id.btnPop);
        pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivityNavigation.this, ShowPopUp.class);
                startActivity(i);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    /*@Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    configureButton();
                return;
        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    private void configureButton() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Criteria cri= new Criteria();
        //locationManager.requestSingleUpdate(cri, );
        locationManager.requestLocationUpdates("gps", 4000, 5, mLocationListener);
        /*Criteria cri= new Criteria();
        String bbb = locationManager.getBestProvider(cri, true);
        longitude= String.valueOf(locationManager.getLastKnownLocation(bbb).getLongitude());
        latitude= String.valueOf(locationManager.getLastKnownLocation(bbb).getLatitude());*/

  //  }
/*
    private void loadList() throws InterruptedException {
        nextPage.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "https://maps.googleapis.com/maps/api/place/textsearch/json?location=" + latitude+","+longitude + "&radius=500&sensor=true&query=cafe&key=AIzaSyBkUpQaDN-FVwsZ2RSGO9euQEb7s5ZI50k");
        SystemClock.sleep(2000);
        synchronized (nextPage) {
            nextPage.wait(1000);
        }
        Log.i("next token", next_page_token);
        json.execute("https://maps.googleapis.com/maps/api/place/textsearch/json?location=" + latitude+","+longitude + "&radius=500&sensor=true&query=cafe&key=AIzaSyBkUpQaDN-FVwsZ2RSGO9euQEb7s5ZI50k&pagetoken=" + next_page_token);


    }*/

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void startMap(View v) throws IOException, InterruptedException {
        Intent i = new Intent(MainActivityNavigation.this, GoogleActivityNavigation.class);
        Bundle bundle = new Bundle();
        /*Criteria cri = new Criteria();
        String bbb = locationManager.getBestProvider(cri, true);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        /*longitude =locationManager.getLastKnownLocation(bbb).getLongitude();
        latitude= locationManager.getLastKnownLocation(bbb).getLatitude();*/
        coord=new LatLng(latitude, longitude);
        bundle.putParcelable("LatLong", coord);
        LinkedSerializable link=new LinkedSerializable(address);
        bundle.putSerializable("address", link);
        i.putExtras(bundle);
        startActivityForResult(i, REQUEST_PLACE_PICKER);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_activity_navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {
            Intent i=new Intent(this, ListActivity.class);
            Bundle bundle = new Bundle();
            LinkedSerializable link=new LinkedSerializable(address);
            bundle.putSerializable("address", link);
            i.putExtras(bundle);
            startActivity(i);
        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    /*public class NextPage extends AsyncTask<String, String, Boolean> {


        @Override
        protected Boolean doInBackground(String... params) {
            URL url = null;
            try {
                url = new URL(params[0]);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpsURLConnection connection = null;
            BufferedReader br = null;
            Log.i("photo references", "dentro 1");
            try
            {
                connection=(HttpsURLConnection) url.openConnection();
                connection.connect();
                InputStream stream;
                stream = connection.getInputStream();
                br = new BufferedReader(new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    buffer.append(line);
                }
                String finalJSOn=buffer.toString();
                JSONObject parentObject= new JSONObject(finalJSOn);
                next_page_token=parentObject.getString("next_page_token");
                JSONArray parentArray=parentObject.getJSONArray("results");
                for(int i=0; i<parentArray.length(); i++) {
                    PlacesModel placesModel=new PlacesModel();
                    JSONObject finalObject=parentArray.getJSONObject(i);
                    if(finalObject.has("photos")) {
                        JSONArray photo=finalObject.getJSONArray("photos");
                        JSONObject photos=photo.getJSONObject(0);
                        placesModel.setPhotoRef(photos.getString("photo_reference"));
                        placesModel.setWidth(photos.getString("width"));
                        Log.i("photo references", placesModel.getPhotoRef());
                    }
                    placesModel.setAddress(finalObject.getString("formatted_address"));
                    placesModel.setName(finalObject.getString("name"));
                    if(finalObject.has("rating")) {
                        placesModel.setRating(finalObject.getString("rating"));
                    }
                    JSONObject second=finalObject.getJSONObject("geometry");
                    JSONObject third=second.getJSONObject("location");
                    placesModel.setLat(third.getString("lat"));
                    placesModel.setLng(third.getString("lng"));
                    address.add(placesModel);
                }
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally
            {

                if (connection != null ) {
                    connection.disconnect();
                }
                try {
                    if (br != null) {
                        br.close();
                    }
                }catch(IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Boolean a) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            super.onPostExecute(a);
            for (int i=0; i<address.size(); i++) {
                Log.i("lista", address.get(i).getName());
            }
        }
    }


    public class JSONTask extends AsyncTask<String, String, LinkedList<PlacesModel>> {

        @Override
        protected LinkedList<PlacesModel> doInBackground(String... params) {

            URL url = null;
            try {
                url = new URL(params[0]);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpsURLConnection connection = null;
            BufferedReader br = null;
            Log.i("photo references", "dentro 2");
            LinkedList<PlacesModel>array=new LinkedList<>();
            try
            {
                connection=(HttpsURLConnection) url.openConnection();
                connection.connect();
                InputStream stream = null;
                stream = connection.getInputStream();
                br = new BufferedReader(new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    buffer.append(line);
                }
                String finalJSOn=buffer.toString();
                JSONObject parentObject= new JSONObject(finalJSOn);
                JSONArray parentArray=parentObject.getJSONArray("results");
                for(int i=0; i<parentArray.length(); i++) {
                    PlacesModel placesModel=new PlacesModel();
                    JSONObject finalObject=parentArray.getJSONObject(i);
                    if(finalObject.has("photos")) {
                        JSONArray photo=finalObject.getJSONArray("photos");
                        JSONObject photos=photo.getJSONObject(0);
                        placesModel.setPhotoRef(photos.getString("photo_reference"));
                        placesModel.setWidth(photos.getString("width"));
                        Log.i("photo references", placesModel.getPhotoRef());

                    }
                    placesModel.setAddress(finalObject.getString("formatted_address"));
                    placesModel.setName(finalObject.getString("name"));
                    if(finalObject.has("rating")) {
                        placesModel.setRating(finalObject.getString("rating"));
                    }
                    JSONObject second=finalObject.getJSONObject("geometry");
                    JSONObject third=second.getJSONObject("location");
                    placesModel.setLat(third.getString("lat"));
                    placesModel.setLng(third.getString("lng"));
                    array.add(placesModel);
                }
                return array;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally
            {

                if (connection != null ) {
                    connection.disconnect();
                }
                try {
                    if (br != null) {
                        br.close();
                    }
                }catch(IOException e) {
                    e.printStackTrace();
                }
            }
            return array;
        }

        @Override
        protected void onPostExecute(LinkedList<PlacesModel> list) {
            super.onPostExecute(list);
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            for (int i=0; i<list.size(); i++) {
                address.add(list.get(i));
            }
            Log.i("lista2", address.getLast().getName());
            PhotoAdapter ph=new PhotoAdapter(getApplicationContext(), R.layout.list, address);
            lv.setAdapter(ph);
        }
    }




*/
    public class PhotoAdapter extends ArrayAdapter {
        private LinkedList<PlacesModel> pm;
        private int resource;
        private LayoutInflater inflater;
        public PhotoAdapter(Context context, int resource, LinkedList<PlacesModel> objects) {
            super(context, resource, objects);
            this.pm=objects;
            this.resource=resource;
            inflater= (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null) {
                convertView=inflater.inflate(resource, null);
            }

            ImageView icon;
            TextView txtMss;
            TextView txtAdr;
            RatingBar rb;
            icon= (ImageView) convertView.findViewById(R.id.photo);
            icon.setImageBitmap(address.get(position).getBitmap());
            rb=(RatingBar) convertView.findViewById(R.id.ratingBar);
            txtMss = (TextView) convertView.findViewById(R.id.txtPuf);
            txtAdr = (TextView) convertView.findViewById(R.id.txtAdr);
            txtMss.setText(address.get(position).getName());
            txtAdr.setText(address.get(position).getAddress());
            /*float j= Float.parseFloat(address.get(position).getRating());
            rb.setRating(j);*/
            return convertView;
        }
    }

        /*public Bitmap getBitmapfromUrl(String src) {
            try {
                URL url=new URL(src);
                HttpsURLConnection connection= (HttpsURLConnection) url.openConnection();
                InputStream input=connection.getInputStream();
                BufferedInputStream is = new BufferedInputStream(input);
                Bitmap myBitmap= BitmapFactory.decodeStream(is);
                return myBitmap;
            }catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }*/


}
